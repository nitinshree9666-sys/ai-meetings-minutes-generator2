# Minute — AI Meeting Minutes Generator

Audio recording/upload ya pasted transcript se, AI ke through structured
meeting minutes (summary, decisions, action items) banata hai — aur unhe
Word ya PDF mein export karta hai.

Stack: **React (Vite)** frontend + **FastAPI (Python)** backend, powered
entirely by **free, local, open-source AI** — no paid API keys needed:
- **faster-whisper** for speech-to-text (runs on your own CPU)
- **Ollama** running an open-source LLM (e.g. Llama 3.1) for summarization

```
meeting-minutes-generator/
├── backend/          FastAPI app, local Whisper + Ollama calls, PDF/DOCX export
└── frontend/         React UI (record / upload audio / upload document / paste tabs)
```

## 0. Install Ollama (one-time, free)

1. Download and install Ollama from **https://ollama.com** (Windows/Mac/Linux).
2. Open a terminal and pull a model (do this once):
   ```bash
   ollama pull llama3.1
   ```
   (Agar tumhara laptop kamzor hai toh chhota model try karo: `ollama pull llama3.2` ya `ollama pull mistral`.)
3. Ollama khud hi background mein `http://localhost:11434` par apna server chala deta hai — alag se "run" karne ki zaroorat nahi, bas installed aur model pulled hona chahiye.

## 1. Backend setup

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# .env file mein defaults already free/local hain — kuch change karne ki
# zaroorat nahi, bas agar tumne alag model pull kiya hai (jaise mistral)
# toh OLLAMA_MODEL wahi naam kar do.

uvicorn main:app --reload --port 8000
```

Pehli baar audio transcribe karoge, Whisper model download hoga
(internet chahiye sirf pehli baar, phir cache ho jata hai — koi cost
nahi hai, ye local model hai).

Backend `http://localhost:8000` par chalega. Health check ke liye:
`http://localhost:8000/api/health` — yaha `ollama_reachable: true` dikhna
chahiye.

## 2. Frontend setup

Naye terminal mein:

```bash
cd frontend
npm install
npm run dev
```

Frontend `http://localhost:5173` par khulega. Vite ka dev server `/api`
requests ko automatically backend (port 8000) par proxy kar deta hai
(`vite.config.js` dekho), so alag se CORS config karne ki zaroorat nahi.

## 3. Use kaise karein

1. Top par **Generate** tab mein left panel se input choose karo:
   - **Record** — seedha microphone se record karo
   - **Upload audio** — audio file upload karo (mp3/wav/m4a/webm/ogg)
   - **Upload document** — pehle se typed transcript/notes wali **PDF ya
     Word (.docx)** file upload karo, uska text nikal ke seedha minutes
     ban jayengi
   - **Paste transcript** — text seedha paste karo
2. Audio/document input pehle local Whisper model se text mein convert
   hota hai, phir local Ollama LLM structured minutes banata hai.
3. Right side par ek document-style output aayega — summary, key points,
   decisions, aur action items table (task / owner / deadline).
4. Neeche **Export as Word** ya **Export as PDF** button se final minutes
   download kar sakte ho.
5. Top par **History** tab par jaake pehle generate ki hui saari minutes
   dekh sakte ho (browser mein locally save hoti hain) — kisi bhi entry
   par click karke usse wapas khol sakte ho, ya ✕ se delete kar sakte ho.

## API endpoints (backend)

| Method | Path                  | Kaam                                                        |
|--------|-----------------------|--------------------------------------------------------------|
| GET    | `/api/health`          | Server, Ollama connectivity, configured models check karne ke liye |
| POST   | `/api/transcribe`      | Audio file upload -> transcript text (local faster-whisper)   |
| POST   | `/api/extract-document`| PDF/DOCX upload -> extracted text                              |
| POST   | `/api/minutes`         | Transcript text -> structured minutes JSON (local Ollama LLM)  |
| POST   | `/api/export/docx`     | Minutes JSON -> `.docx` file                                   |
| POST   | `/api/export/pdf`      | Minutes JSON -> `.pdf` file                                     |

## Aage kya add kar sakte ho (synopsis ka "Future Scope")

- Speaker diarization (kaun bol raha hai, wo identify karna)
- Multilingual transcription/summarization
- Zoom / Google Meet / Teams se direct integration
- Finalized minutes ka email delivery
- Calendar/task-manager integration action items ke liye

## Notes

- Koi API key ki zaroorat nahi — sab kuch local machine par chalta hai,
  free hai. Bas Ollama installed hona chahiye aur ek model pulled hona
  chahiye (`ollama pull llama3.1`).
- Agar `/api/minutes` call fail ho with "Could not reach Ollama" error,
  matlab Ollama app chal nahi raha — ek baar `ollama run llama3.1` terminal
  mein chala do (khud test karne ke liye), phir usse close kar sakte ho,
  Ollama background service already ready ho jata hai.
- Agar transcription mein error aaye, `ffmpeg` install kar lena system
  mein (faster-whisper isse audio decode karne ke liye use karta hai) —
  Windows: `winget install ffmpeg`, Mac: `brew install ffmpeg`.
- Bada/lamba audio ya document CPU par slow chal sakta hai — chhota
  Whisper model (`WHISPER_MODEL_SIZE=tiny`) ya chhota Ollama model
  (`llama3.2` / `mistral`) use karke speed badha sakte ho.
- Production mein `CORSMiddleware` ke `allow_origins=["*"]` ko apne actual
  frontend domain se replace kar dena.

### Baad mein OpenAI (paid) par wapas jaana ho toh

Ye setup jaan-boojh ke free/local rakha hai. Agar kabhi OpenAI credits
mil jayein aur behtar accuracy chahiye ho, bata dena — Whisper API aur
GPT wapas plug kar denge, bas `.env` mein settings badalni hongi, poora
code dobara likhna nahi padega.
