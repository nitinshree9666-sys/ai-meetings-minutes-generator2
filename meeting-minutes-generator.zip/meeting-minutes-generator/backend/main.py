"""
AI Meeting Minutes Generator - Backend
---------------------------------------
FastAPI service that:
  1. Transcribes uploaded meeting audio using a LOCAL, free Whisper model
     (faster-whisper) — no API key, no per-minute cost.
  2. Turns a transcript (from audio, a document, or pasted text) into
     structured meeting minutes (summary, decisions, action items) using
     a LOCAL, free open-source LLM served by Ollama.
  3. Exports the generated minutes as a PDF or Word (.docx) document.

Run with:
    uvicorn main:app --reload --port 8000

Requires:
  - Ollama installed and running (https://ollama.com) with a model pulled,
    e.g.:  ollama pull llama3.1
  - faster-whisper downloads its model automatically on first use
    (needs internet the first time only; then it's cached locally).
"""

import io
import json
import os
from datetime import datetime
from typing import List, Optional

import requests
from dotenv import load_dotenv
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

load_dotenv()

# --- Local LLM (Ollama) ------------------------------------------------
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.1")

# --- Local Speech-to-Text (faster-whisper) ------------------------------
WHISPER_MODEL_SIZE = os.getenv("WHISPER_MODEL_SIZE", "base")  # tiny/base/small/medium/large-v3
_whisper_model = None  # lazy-loaded on first transcription request


def get_whisper_model():
    """Loads the faster-whisper model once and reuses it across requests."""
    global _whisper_model
    if _whisper_model is None:
        from faster_whisper import WhisperModel

        print(f"Loading local Whisper model '{WHISPER_MODEL_SIZE}' (first run downloads it)...")
        _whisper_model = WhisperModel(WHISPER_MODEL_SIZE, device="cpu", compute_type="int8")
    return _whisper_model


app = FastAPI(title="AI Meeting Minutes Generator")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def catch_all_exception_handler(request, exc):  # noqa: ANN001
    from fastapi.responses import JSONResponse

    return JSONResponse(status_code=500, content={"detail": f"Unexpected server error: {exc}"})


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------

class TranscriptRequest(BaseModel):
    transcript: str = Field(..., min_length=1)
    meeting_title: Optional[str] = None


class ActionItem(BaseModel):
    task: str
    owner: Optional[str] = "Unassigned"
    deadline: Optional[str] = "Not specified"


class MeetingMinutes(BaseModel):
    title: str
    date: str
    attendees: List[str] = []
    summary: str
    key_points: List[str] = []
    decisions: List[str] = []
    action_items: List[ActionItem] = []


class TranscribeResponse(BaseModel):
    transcript: str


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------

@app.get("/api/health")
def health():
    ollama_ok = False
    try:
        r = requests.get(f"{OLLAMA_BASE_URL}/api/tags", timeout=2)
        ollama_ok = r.status_code == 200
    except Exception:  # noqa: BLE001
        ollama_ok = False

    return {
        "status": "ok",
        "llm_provider": "ollama",
        "llm_model": OLLAMA_MODEL,
        "ollama_reachable": ollama_ok,
        "stt_provider": "faster-whisper (local)",
        "whisper_model_size": WHISPER_MODEL_SIZE,
    }


# ---------------------------------------------------------------------------
# 1. Audio -> Transcript (Whisper)
# ---------------------------------------------------------------------------

@app.post("/api/transcribe", response_model=TranscribeResponse)
async def transcribe_audio(file: UploadFile = File(...)):
    allowed_ext = (".mp3", ".mp4", ".mpeg", ".mpga", ".m4a", ".wav", ".webm", ".ogg")
    if not file.filename.lower().endswith(allowed_ext):
        raise HTTPException(400, f"Unsupported file type. Allowed: {allowed_ext}")

    audio_bytes = await file.read()
    if not audio_bytes:
        raise HTTPException(400, "Uploaded audio file is empty.")

    try:
        model = get_whisper_model()
        segments, _info = model.transcribe(io.BytesIO(audio_bytes), beam_size=5)
        transcript = " ".join(segment.text.strip() for segment in segments).strip()
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(
            502,
            "Local transcription failed. Make sure ffmpeg is installed and the "
            f"audio file isn't corrupted. Details: {exc}",
        ) from exc

    if not transcript:
        raise HTTPException(422, "Could not detect any speech in this audio file.")

    return TranscribeResponse(transcript=transcript)


# ---------------------------------------------------------------------------
# 1b. Document (PDF / DOCX) -> Extracted Text
# ---------------------------------------------------------------------------

@app.post("/api/extract-document", response_model=TranscribeResponse)
async def extract_document(file: UploadFile = File(...)):
    """Accepts a PDF or Word document (e.g. an already-typed transcript, notes
    file, or exported chat log) and extracts its raw text so it can be sent
    straight into /api/minutes, exactly like a pasted transcript would be."""

    filename = file.filename.lower()
    file_bytes = await file.read()
    if not file_bytes:
        raise HTTPException(400, "Uploaded document is empty.")

    try:
        if filename.endswith(".pdf"):
            text = _extract_pdf_text(file_bytes)
        elif filename.endswith(".docx"):
            text = _extract_docx_text(file_bytes)
        else:
            raise HTTPException(400, "Unsupported file type. Please upload a .pdf or .docx file.")
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(
            422,
            "Could not read this file. Make sure it's a valid, non-corrupted "
            f".pdf or .docx (not a renamed .doc). Details: {exc}",
        ) from exc

    if not text.strip():
        raise HTTPException(
            422,
            "Could not find any readable text in this document. "
            "If it's a scanned/image-only PDF, try a text-based file instead.",
        )

    return TranscribeResponse(transcript=text)


def _extract_pdf_text(file_bytes: bytes) -> str:
    import pdfplumber

    text_parts = []
    with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text() or ""
            if page_text.strip():
                text_parts.append(page_text)
    return "\n\n".join(text_parts)


def _extract_docx_text(file_bytes: bytes) -> str:
    from docx import Document as DocxDocument

    doc = DocxDocument(io.BytesIO(file_bytes))
    parts = [p.text for p in doc.paragraphs if p.text.strip()]
    for table in doc.tables:
        for row in table.rows:
            row_text = " | ".join(cell.text.strip() for cell in row.cells if cell.text.strip())
            if row_text:
                parts.append(row_text)
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# 2. Transcript -> Structured Minutes (LLM)
# ---------------------------------------------------------------------------

MINUTES_SYSTEM_PROMPT = """You are an assistant that converts raw meeting transcripts into
clean, structured meeting minutes. Read the transcript carefully and respond with STRICT JSON
only (no markdown fences, no commentary) matching exactly this schema:

{
  "title": "short descriptive meeting title",
  "date": "date mentioned in the transcript, or 'Not specified'",
  "attendees": ["list of participant names mentioned, or empty list"],
  "summary": "a concise 3-6 sentence summary of what was discussed",
  "key_points": ["bullet list of the main discussion points"],
  "decisions": ["bullet list of concrete decisions that were made"],
  "action_items": [
    {"task": "what needs to be done", "owner": "person responsible or 'Unassigned'", "deadline": "date/timeframe or 'Not specified'"}
  ]
}

Rules:
- Only include information that is actually supported by the transcript. Do not invent names, dates or tasks.
- If a field cannot be determined, use an empty list or "Not specified" as shown above.
- Keep the summary factual and neutral in tone.
"""


MAX_TRANSCRIPT_CHARS = 60_000  # keeps large documents within a safe LLM context size


def _call_ollama_json(system_prompt: str, user_prompt: str) -> str:
    """Calls a local Ollama server and returns the raw JSON string the model produced."""
    response = requests.post(
        f"{OLLAMA_BASE_URL}/api/chat",
        json={
            "model": OLLAMA_MODEL,
            "format": "json",
            "stream": False,
            "options": {"temperature": 0.2},
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        },
        timeout=300,
    )
    if response.status_code == 404:
        raise HTTPException(
            502,
            f"Model '{OLLAMA_MODEL}' is not pulled yet. Run: `ollama pull {OLLAMA_MODEL}`",
        )
    response.raise_for_status()
    return response.json()["message"]["content"]


@app.post("/api/minutes", response_model=MeetingMinutes)
def generate_minutes(payload: TranscriptRequest):
    if not payload.transcript.strip():
        raise HTTPException(400, "Transcript is empty.")

    transcript = payload.transcript
    if len(transcript) > MAX_TRANSCRIPT_CHARS:
        transcript = transcript[:MAX_TRANSCRIPT_CHARS]

    user_prompt = transcript
    if payload.meeting_title:
        user_prompt = f"Meeting title hint: {payload.meeting_title}\n\nTranscript:\n{transcript}"

    try:
        raw = _call_ollama_json(MINUTES_SYSTEM_PROMPT, user_prompt)
        data = json.loads(raw)
    except requests.exceptions.ConnectionError as exc:
        raise HTTPException(
            502,
            "Could not reach Ollama at "
            f"{OLLAMA_BASE_URL}. Make sure Ollama is installed and running "
            f"(try: `ollama run {OLLAMA_MODEL}` in a terminal first).",
        ) from exc
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(502, f"Minutes generation failed: {exc}") from exc

    # Fill sensible defaults if the model omits a field
    data.setdefault("title", payload.meeting_title or "Untitled Meeting")
    data.setdefault("date", datetime.now().strftime("%Y-%m-%d"))
    data.setdefault("attendees", [])
    data.setdefault("summary", "")
    data.setdefault("key_points", [])
    data.setdefault("decisions", [])
    data.setdefault("action_items", [])

    return MeetingMinutes(**data)


# ---------------------------------------------------------------------------
# 3. Export - DOCX
# ---------------------------------------------------------------------------

@app.post("/api/export/docx")
def export_docx(minutes: MeetingMinutes):
    from docx import Document
    from docx.shared import Pt, RGBColor

    doc = Document()

    title = doc.add_heading(minutes.title, level=0)

    meta = doc.add_paragraph()
    meta.add_run(f"Date: {minutes.date}").bold = True
    if minutes.attendees:
        doc.add_paragraph("Attendees: " + ", ".join(minutes.attendees))

    doc.add_heading("Summary", level=1)
    doc.add_paragraph(minutes.summary or "Not specified")

    if minutes.key_points:
        doc.add_heading("Key Discussion Points", level=1)
        for point in minutes.key_points:
            doc.add_paragraph(point, style="List Bullet")

    if minutes.decisions:
        doc.add_heading("Decisions", level=1)
        for decision in minutes.decisions:
            doc.add_paragraph(decision, style="List Bullet")

    if minutes.action_items:
        doc.add_heading("Action Items", level=1)
        table = doc.add_table(rows=1, cols=3)
        table.style = "Light Grid Accent 1"
        hdr = table.rows[0].cells
        hdr[0].text, hdr[1].text, hdr[2].text = "Task", "Owner", "Deadline"
        for item in minutes.action_items:
            row = table.add_row().cells
            row[0].text = item.task
            row[1].text = item.owner or "Unassigned"
            row[2].text = item.deadline or "Not specified"

    buffer = io.BytesIO()
    doc.save(buffer)
    buffer.seek(0)

    filename = f"{minutes.title.replace(' ', '_')}_minutes.docx"
    return StreamingResponse(
        buffer,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# ---------------------------------------------------------------------------
# 4. Export - PDF
# ---------------------------------------------------------------------------

@app.post("/api/export/pdf")
def export_pdf(minutes: MeetingMinutes):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.platypus import (
        SimpleDocTemplate,
        Paragraph,
        Spacer,
        Table,
        TableStyle,
        ListFlowable,
        ListItem,
    )
    from reportlab.lib import colors

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, topMargin=2 * cm, bottomMargin=2 * cm)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="MinutesTitle", fontSize=20, spaceAfter=6, textColor=colors.HexColor("#1F2A24")))
    styles.add(ParagraphStyle(name="SectionHeading", fontSize=13, spaceBefore=14, spaceAfter=6, textColor=colors.HexColor("#3B6E5E")))

    story = [Paragraph(minutes.title, styles["MinutesTitle"])]
    story.append(Paragraph(f"<b>Date:</b> {minutes.date}", styles["Normal"]))
    if minutes.attendees:
        story.append(Paragraph(f"<b>Attendees:</b> {', '.join(minutes.attendees)}", styles["Normal"]))

    story.append(Paragraph("Summary", styles["SectionHeading"]))
    story.append(Paragraph(minutes.summary or "Not specified", styles["Normal"]))

    if minutes.key_points:
        story.append(Paragraph("Key Discussion Points", styles["SectionHeading"]))
        story.append(ListFlowable(
            [ListItem(Paragraph(p, styles["Normal"])) for p in minutes.key_points],
            bulletType="bullet",
        ))

    if minutes.decisions:
        story.append(Paragraph("Decisions", styles["SectionHeading"]))
        story.append(ListFlowable(
            [ListItem(Paragraph(d, styles["Normal"])) for d in minutes.decisions],
            bulletType="bullet",
        ))

    if minutes.action_items:
        story.append(Paragraph("Action Items", styles["SectionHeading"]))
        table_data = [["Task", "Owner", "Deadline"]] + [
            [item.task, item.owner or "Unassigned", item.deadline or "Not specified"]
            for item in minutes.action_items
        ]
        table = Table(table_data, colWidths=[8 * cm, 4 * cm, 4 * cm])
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#3B6E5E")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CCCCCC")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F4F6F3")]),
        ]))
        story.append(table)

    doc.build(story)
    buffer.seek(0)

    filename = f"{minutes.title.replace(' ', '_')}_minutes.pdf"
    return StreamingResponse(
        buffer,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
