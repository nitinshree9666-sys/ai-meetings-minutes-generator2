import Icon from "./Icon.jsx";

const FEATURES = [
  { icon: "mic", title: "Record live", text: "Capture the meeting straight from your microphone and transcribe with one click." },
  { icon: "upload", title: "Upload audio", text: "Drop in MP3, WAV, M4A, WEBM or OGG recordings from any call." },
  { icon: "file", title: "Read documents", text: "Turn PDF or Word notes and transcripts into structured minutes — no audio needed." },
  { icon: "check", title: "Decisions & actions", text: "Every decision and task is pulled out, with the owner and deadline attached." },
  { icon: "download", title: "Word & PDF export", text: "Download share-ready minutes in the format your team already uses." },
  { icon: "shield", title: "Private history", text: "Past minutes are saved locally in your browser so you can reopen them anytime." },
];

const STEPS = [
  { n: "01", title: "Bring in the meeting", text: "Record, upload audio, upload a document, or paste a transcript." },
  { n: "02", title: "AI drafts the minutes", text: "Summary, key points, decisions and action items are generated automatically." },
  { n: "03", title: "Review & export", text: "Skim the document, then download it as Word or PDF." },
];

export default function Features() {
  return (
    <>
      <section id="features" className="relative mx-auto max-w-7xl scroll-mt-24 px-5 py-24">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-violet-400">Features</span>
          <h2 className="mt-3 text-3xl font-semibold tracking-tight text-white md:text-5xl">
            Everything you need to <span className="text-gradient">stop taking notes</span>
          </h2>
        </div>
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div
              key={f.title}
              className="glass group rounded-2xl p-6 transition duration-300 hover:-translate-y-1 hover:border-violet-400/40 hover:bg-white/[0.06]"
            >
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-violet-500/30 to-indigo-500/10 text-violet-300 ring-1 ring-violet-400/20 transition group-hover:scale-110">
                <Icon name={f.icon} className="h-5 w-5" />
              </span>
              <h3 className="mt-5 text-lg font-semibold text-white">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-zinc-400">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="how" className="mx-auto max-w-7xl scroll-mt-24 px-5 pb-24">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-semibold uppercase tracking-widest text-violet-400">How it works</span>
          <h2 className="mt-3 text-3xl font-semibold tracking-tight text-white md:text-5xl">Three steps. Zero busywork.</h2>
        </div>
        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {STEPS.map((s) => (
            <div key={s.n} className="relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.05] to-transparent p-7">
              <div className="text-gradient text-5xl font-bold">{s.n}</div>
              <h3 className="mt-4 text-lg font-semibold text-white">{s.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-zinc-400">{s.text}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
