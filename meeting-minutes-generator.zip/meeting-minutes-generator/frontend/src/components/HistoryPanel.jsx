import Icon from "./Icon.jsx";

export default function HistoryPanel({ history, onOpen, onDelete }) {
  return (
    <section className="mx-auto max-w-4xl px-5 pb-24 pt-32">
      <div className="mb-10">
        <span className="text-sm font-semibold uppercase tracking-widest text-violet-400">History</span>
        <h2 className="mt-2 text-3xl font-semibold tracking-tight text-white md:text-4xl">Your saved minutes</h2>
        <p className="mt-2 text-sm text-zinc-500">Stored only in this browser — the last 50 meetings.</p>
      </div>

      {!history.length ? (
        <div className="glass flex flex-col items-center rounded-3xl border-dashed p-14 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-violet-500/15 text-violet-300">
            <Icon name="history" className="h-7 w-7" />
          </span>
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-zinc-500">
            No minutes yet. Once you generate a set, it&apos;s saved here automatically so you can come back to it.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {history.map((entry) => (
            <div
              key={entry.id}
              className="glass group flex items-start gap-3 rounded-2xl p-5 transition hover:border-violet-400/40 hover:bg-white/[0.06]"
            >
              <button className="min-w-0 flex-1 text-left" onClick={() => onOpen(entry)}>
                <div className="truncate text-lg font-semibold text-white">{entry.minutes.title}</div>
                <div className="mt-1 flex items-center gap-1.5 text-xs text-zinc-500">
                  <Icon name="clock" className="h-3.5 w-3.5" />
                  {entry.minutes.date} · saved {new Date(entry.createdAt).toLocaleString()}
                </div>
                <p className="mt-3 line-clamp-2 text-sm leading-relaxed text-zinc-400">{entry.minutes.summary}</p>
              </button>
              <button
                title="Delete"
                aria-label="Delete"
                onClick={() => onDelete(entry.id)}
                className="rounded-lg p-2 text-zinc-500 transition hover:bg-rose-500/10 hover:text-rose-300"
              >
                <Icon name="trash" className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
