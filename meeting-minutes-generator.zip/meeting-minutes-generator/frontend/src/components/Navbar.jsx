import Icon from "./Icon.jsx";

export default function Navbar({ view, setView, historyCount, hasMinutes, onNew }) {
  const tab = (id, label, extra) => (
    <button
      onClick={() => setView(id)}
      className={`rounded-lg px-3.5 py-2 text-sm font-medium transition ${
        view === id ? "bg-white/10 text-white" : "text-zinc-400 hover:text-white"
      }`}
    >
      {label}
      {extra}
    </button>
  );

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-white/5 bg-zinc-950/70 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5">
        <button onClick={() => setView("generate")} className="flex items-center gap-2.5">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-violet-500 to-indigo-600 text-white shadow-lg shadow-violet-500/30">
            <Icon name="sparkles" className="h-4 w-4" />
          </span>
          <span className="text-lg font-semibold tracking-tight text-white">
            Minute<span className="text-violet-400">.</span>
          </span>
        </button>

        <nav className="flex items-center gap-1">
          {view === "generate" && (
            <>
              <a href="#features" className="hidden px-3 py-2 text-sm text-zinc-400 hover:text-white md:block">Features</a>
              <a href="#how" className="hidden px-3 py-2 text-sm text-zinc-400 hover:text-white md:block">How it works</a>
            </>
          )}
          {tab("generate", "Generate")}
          {tab(
            "history",
            "History",
            historyCount > 0 && (
              <span className="ml-2 rounded-full bg-violet-500/20 px-2 py-0.5 text-xs text-violet-300">{historyCount}</span>
            )
          )}
          {hasMinutes && (
            <button className="btn-ghost ml-2 !px-3 !py-2" onClick={onNew}>
              <Icon name="plus" /> New
            </button>
          )}
        </nav>
      </div>
    </header>
  );
}
