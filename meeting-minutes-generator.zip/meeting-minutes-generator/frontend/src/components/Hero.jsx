import Icon from "./Icon.jsx";

const BARS = [30, 55, 80, 45, 95, 60, 35, 75, 50, 90, 40, 65, 85, 45, 70, 30, 60, 80, 50, 35];

export default function Hero() {
  return (
    <section className="relative overflow-hidden pb-24 pt-36">
      <div className="bg-grid absolute inset-0" />
      <div className="pointer-events-none absolute left-1/2 top-0 h-[520px] w-[820px] -translate-x-1/2 rounded-full bg-violet-600/25 blur-[130px]" />
      <div className="pointer-events-none absolute right-0 top-40 h-72 w-72 rounded-full bg-cyan-500/15 blur-[110px]" />

      <div className="relative mx-auto max-w-7xl px-5">
        <div className="mx-auto max-w-3xl animate-fade-up text-center">
          <span className="glass inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium text-violet-200">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
            Audio · Documents · Transcripts → Minutes
          </span>
          <h1 className="mt-7 text-5xl font-semibold leading-[1.05] tracking-tight text-white md:text-7xl">
            Turn every meeting into <span className="text-gradient">crystal-clear minutes</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-zinc-400">
            Record it, upload it, or paste it. Minute drafts a polished summary with decisions,
            owners and deadlines — ready to export as Word or PDF in seconds.
          </p>
          <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <a href="#workspace" className="btn-primary px-7 py-3.5 text-base">
              Start generating <Icon name="arrow" />
            </a>
            <a href="#how" className="btn-ghost px-7 py-3.5 text-base">See how it works</a>
          </div>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-zinc-500">
            <span className="flex items-center gap-1.5"><Icon name="check" className="h-4 w-4 text-emerald-400" /> Word &amp; PDF export</span>
            <span className="flex items-center gap-1.5"><Icon name="check" className="h-4 w-4 text-emerald-400" /> Owners &amp; deadlines detected</span>
            <span className="flex items-center gap-1.5"><Icon name="check" className="h-4 w-4 text-emerald-400" /> History stays on your device</span>
          </div>
        </div>

        {/* Product preview */}
        <div className="relative mx-auto mt-20 max-w-5xl animate-float">
          <div className="absolute -inset-4 rounded-[2rem] bg-gradient-to-r from-violet-600/30 via-fuchsia-500/20 to-cyan-500/30 blur-2xl" />
          <div className="glass relative rounded-3xl p-2 shadow-2xl shadow-black/60">
            <div className="rounded-2xl bg-zinc-950/80 p-5 md:p-7">
              <div className="mb-5 flex items-center gap-2">
                <span className="h-3 w-3 rounded-full bg-rose-400/80" />
                <span className="h-3 w-3 rounded-full bg-amber-400/80" />
                <span className="h-3 w-3 rounded-full bg-emerald-400/80" />
                <span className="ml-3 text-xs text-zinc-500">Weekly sprint sync · 24:18</span>
              </div>
              <div className="grid gap-5 md:grid-cols-[1fr_1.15fr]">
                <div className="rounded-xl border border-white/5 bg-white/[0.02] p-5">
                  <div className="flex items-center gap-2 text-sm font-medium text-white">
                    <span className="grid h-8 w-8 place-items-center rounded-full bg-rose-500/20 text-rose-300"><Icon name="mic" /></span>
                    Listening…
                  </div>
                  <div className="mt-6 flex h-24 items-center justify-between gap-1">
                    {BARS.map((h, i) => (
                      <span
                        key={i}
                        className="w-full origin-center animate-wave rounded-full bg-gradient-to-t from-violet-500 to-cyan-300"
                        style={{ height: `${h}%`, animationDelay: `${i * 70}ms` }}
                      />
                    ))}
                  </div>
                </div>
                <div className="space-y-4 rounded-xl border border-white/5 bg-white/[0.02] p-5 text-left">
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-wider text-violet-300">Summary</div>
                    <p className="mt-1.5 text-sm leading-relaxed text-zinc-300">
                      Team agreed to ship the beta on the 14th and move the analytics work to next sprint.
                    </p>
                  </div>
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-wider text-violet-300">Action items</div>
                    <div className="mt-2 space-y-2">
                      {[["Finalize onboarding copy", "Priya", "Fri"], ["Fix export bug on PDF", "Marcus", "Mon"]].map(([t, o, d]) => (
                        <div key={t} className="flex items-center justify-between gap-3 rounded-lg bg-white/5 px-3 py-2 text-sm">
                          <span className="text-zinc-200">{t}</span>
                          <span className="flex shrink-0 items-center gap-2 text-xs">
                            <span className="rounded-full bg-violet-500/20 px-2 py-0.5 text-violet-300">{o}</span>
                            <span className="text-zinc-500">{d}</span>
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
