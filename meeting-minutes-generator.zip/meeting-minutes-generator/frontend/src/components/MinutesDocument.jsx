import Icon from "./Icon.jsx";

function Section({ title, children }) {
  return (
    <section className="mt-8">
      <h3 className="mb-3 flex items-center gap-3 text-xs font-bold uppercase tracking-[0.18em] text-violet-700">
        {title}
        <span className="h-px flex-1 bg-zinc-200" />
      </h3>
      {children}
    </section>
  );
}

function Bullets({ items }) {
  return (
    <ul className="space-y-2.5">
      {items.map((item, i) => (
        <li key={i} className="flex gap-3 leading-relaxed">
          <span className="mt-2.5 h-1.5 w-1.5 shrink-0 rounded-full bg-violet-500" />
          <span>{item}</span>
        </li>
      ))}
    </ul>
  );
}

export default function MinutesDocument({ minutes, onExport, isExporting, isBusy }) {
  if (isBusy) {
    return (
      <div className="animate-fade-up rounded-3xl bg-[#fbfaf7] p-8 shadow-2xl shadow-black/50 md:p-12">
        <div className="skeleton h-9 w-3/4" />
        <div className="skeleton mt-4 h-4 w-1/3" />
        <div className="mt-10 space-y-3">
          {[100, 95, 88, 92, 60].map((w, i) => (
            <div key={i} className="skeleton h-4" style={{ width: `${w}%` }} />
          ))}
        </div>
        <div className="skeleton mt-10 h-32 w-full" />
      </div>
    );
  }

  if (!minutes) {
    return (
      <div className="glass flex min-h-[460px] flex-col items-center justify-center rounded-3xl border-dashed p-10 text-center">
        <span className="grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-violet-500/25 to-cyan-500/10 text-violet-300 ring-1 ring-violet-400/20">
          <Icon name="file" className="h-8 w-8" />
        </span>
        <h3 className="mt-6 text-xl font-semibold text-white">Your minutes will appear here</h3>
        <p className="mt-2 max-w-sm text-sm leading-relaxed text-zinc-500">
          Record, upload, or paste a transcript. The summary, decisions and action items land here — ready to review and export.
        </p>
      </div>
    );
  }

  return (
    <div className="animate-fade-up">
      <article className="rounded-3xl bg-[#fbfaf7] p-8 text-zinc-700 shadow-2xl shadow-black/50 md:p-12">
        <header className="border-b-2 border-zinc-900 pb-6">
          <div className="text-xs font-bold uppercase tracking-[0.2em] text-violet-700">Meeting minutes</div>
          <h1 className="mt-2 font-serif text-3xl font-bold leading-tight text-zinc-900 md:text-4xl">{minutes.title}</h1>
          <div className="mt-4 flex flex-wrap gap-x-6 gap-y-2 text-sm text-zinc-500">
            <span className="flex items-center gap-1.5"><Icon name="clock" className="h-4 w-4" /> {minutes.date}</span>
            {minutes.attendees?.length > 0 && (
              <span className="flex items-center gap-1.5"><Icon name="users" className="h-4 w-4" /> {minutes.attendees.join(", ")}</span>
            )}
          </div>
        </header>

        <Section title="Summary">
          <p className="font-serif text-lg leading-relaxed text-zinc-800">{minutes.summary || "Not specified"}</p>
        </Section>

        {minutes.key_points?.length > 0 && (
          <Section title="Key discussion points"><Bullets items={minutes.key_points} /></Section>
        )}

        {minutes.decisions?.length > 0 && (
          <Section title="Decisions">
            <div className="space-y-2.5">
              {minutes.decisions.map((d, i) => (
                <div key={i} className="flex gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 leading-relaxed text-emerald-900">
                  <Icon name="check" className="mt-1 h-4 w-4 shrink-0 text-emerald-600" />
                  <span>{d}</span>
                </div>
              ))}
            </div>
          </Section>
        )}

        {minutes.action_items?.length > 0 && (
          <Section title="Action items">
            <div className="overflow-x-auto rounded-xl border border-zinc-200">
              <table className="w-full min-w-[480px] text-left text-sm">
                <thead className="bg-zinc-100 text-xs uppercase tracking-wider text-zinc-500">
                  <tr>
                    <th className="px-4 py-3 font-semibold">Task</th>
                    <th className="px-4 py-3 font-semibold">Owner</th>
                    <th className="px-4 py-3 font-semibold">Deadline</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 bg-white">
                  {minutes.action_items.map((item, i) => (
                    <tr key={i}>
                      <td className="px-4 py-3 text-zinc-800">{item.task}</td>
                      <td className="px-4 py-3">
                        <span className="rounded-full bg-violet-100 px-2.5 py-1 text-xs font-medium text-violet-700">
                          {item.owner || "Unassigned"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-zinc-500">{item.deadline || "Not specified"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Section>
        )}
      </article>

      <div className="mt-4 flex flex-col gap-3 sm:flex-row">
        <button className="btn-primary flex-1" disabled={isExporting} onClick={() => onExport("docx")}>
          <Icon name="download" /> Export as Word
        </button>
        <button className="btn-ghost flex-1" disabled={isExporting} onClick={() => onExport("pdf")}>
          <Icon name="download" /> Export as PDF
        </button>
      </div>
    </div>
  );
}
