import { useEffect, useRef, useState } from "react";
import Icon from "./Icon.jsx";

const TABS = [
  { id: "record", label: "Record", icon: "mic" },
  { id: "upload", label: "Audio", icon: "upload" },
  { id: "document", label: "Document", icon: "file" },
  { id: "paste", label: "Paste", icon: "text" },
];

function DropZone({ accept, hint, prompt, icon, fileName, onFile, validate }) {
  const [dragging, setDragging] = useState(false);
  const pick = (file) => {
    if (!file) return;
    if (validate && !validate(file)) return;
    onFile(file);
  };
  return (
    <div>
      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => { e.preventDefault(); setDragging(false); pick(e.dataTransfer.files?.[0]); }}
        className={`rounded-2xl border-2 border-dashed p-8 text-center transition ${
          dragging ? "border-violet-400 bg-violet-500/10" : "border-white/10 bg-white/[0.02] hover:border-violet-400/40"
        }`}
      >
        <span className="mx-auto grid h-12 w-12 place-items-center rounded-xl bg-violet-500/15 text-violet-300">
          <Icon name={icon} className="h-6 w-6" />
        </span>
        <p className="mt-4 text-sm text-zinc-300">{prompt}</p>
        <label className="mt-1 inline-block cursor-pointer text-sm font-medium text-violet-300 underline underline-offset-4 hover:text-violet-200">
          browse your files
          <input type="file" accept={accept} hidden onChange={(e) => pick(e.target.files?.[0])} />
        </label>
        <div className="mt-2 text-xs text-zinc-500">{hint}</div>
      </div>
      {fileName && (
        <div className="mt-3 flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-zinc-200">
          <Icon name="check" className="h-4 w-4 text-emerald-400" />
          <span className="truncate">{fileName}</span>
        </div>
      )}
    </div>
  );
}

export default function InputPanel({
  onTranscribeFile,
  onExtractDocument,
  onUseTranscript,
  isBusy,
  statusMessage,
  errorMessage,
}) {
  const [activeTab, setActiveTab] = useState("record");
  const [isRecording, setIsRecording] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [micError, setMicError] = useState("");
  const [fileName, setFileName] = useState("");
  const [docFileName, setDocFileName] = useState("");
  const [pastedText, setPastedText] = useState("");
  const [meetingTitle, setMeetingTitle] = useState("");

  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);

  useEffect(() => {
    if (!isRecording) return;
    const id = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => clearInterval(id);
  }, [isRecording]);

  async function startRecording() {
    setMicError("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        stream.getTracks().forEach((track) => track.stop());
        const file = new File([blob], "recording.webm", { type: "audio/webm" });
        onTranscribeFile(file, meetingTitle);
      };
      recorder.start();
      mediaRecorderRef.current = recorder;
      setSeconds(0);
      setIsRecording(true);
    } catch {
      setMicError("Microphone access was blocked. Allow it in your browser and try again.");
    }
  }

  function stopRecording() {
    mediaRecorderRef.current?.stop();
    setIsRecording(false);
  }

  const mmss = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;

  return (
    <div className="glass rounded-3xl p-6 shadow-2xl shadow-black/40 md:p-7">
      <div className="flex items-center gap-3">
        <span className="grid h-8 w-8 place-items-center rounded-lg bg-violet-500/20 text-sm font-bold text-violet-300">1</span>
        <h2 className="text-lg font-semibold text-white">Bring in the meeting</h2>
      </div>

      <div className="mt-5 grid grid-cols-4 gap-1 rounded-xl border border-white/10 bg-zinc-900/60 p-1">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`flex flex-col items-center gap-1 rounded-lg px-1 py-2 text-xs font-medium transition ${
              activeTab === tab.id
                ? "bg-gradient-to-br from-violet-500 to-indigo-500 text-white shadow-md shadow-violet-500/20"
                : "text-zinc-400 hover:bg-white/5 hover:text-white"
            }`}
          >
            <Icon name={tab.icon} className="h-4 w-4" />
            {tab.label}
          </button>
        ))}
      </div>

      <label className="mb-1.5 mt-5 block text-xs font-medium uppercase tracking-wider text-zinc-500" htmlFor="meeting-title">
        Meeting title (optional)
      </label>
      <input
        id="meeting-title"
        className="input-dark mb-5"
        placeholder="e.g. Weekly sprint sync"
        value={meetingTitle}
        onChange={(e) => setMeetingTitle(e.target.value)}
      />

      {activeTab === "record" && (
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-6 text-center">
          <div className="relative mx-auto grid h-24 w-24 place-items-center">
            {isRecording && (
              <>
                <span className="absolute h-16 w-16 animate-ring rounded-full bg-rose-500/40" />
                <span className="absolute h-16 w-16 animate-ring rounded-full bg-rose-500/40 [animation-delay:.6s]" />
              </>
            )}
            <button
              onClick={isRecording ? stopRecording : startRecording}
              disabled={isBusy}
              aria-label={isRecording ? "Stop and transcribe" : "Start recording"}
              className={`relative grid h-16 w-16 place-items-center rounded-full text-white shadow-xl transition hover:scale-105 disabled:opacity-50 ${
                isRecording ? "bg-rose-500 shadow-rose-500/40" : "bg-gradient-to-br from-violet-500 to-indigo-500 shadow-violet-500/40"
              }`}
            >
              <Icon name={isRecording ? "stop" : "mic"} className="h-6 w-6" />
            </button>
          </div>
          <div className="mt-3 text-2xl font-semibold tabular-nums text-white">{isRecording ? mmss : "Ready"}</div>
          <p className="mt-1 text-sm text-zinc-500">
            {isRecording ? "Recording… tap to stop & transcribe" : "Tap the mic and start your meeting"}
          </p>
          {micError && <p className="mt-3 text-sm text-rose-300">{micError}</p>}
        </div>
      )}

      {activeTab === "upload" && (
        <DropZone
          accept="audio/*"
          icon="upload"
          prompt="Drag an audio file here, or"
          hint="MP3, WAV, M4A, WEBM, OGG"
          fileName={fileName}
          onFile={(file) => { setFileName(file.name); onTranscribeFile(file, meetingTitle); }}
        />
      )}

      {activeTab === "document" && (
        <div>
          <p className="mb-3 text-sm leading-relaxed text-zinc-500">
            Already have notes or a transcript saved as a file? Upload a PDF or Word document — no audio needed.
          </p>
          <DropZone
            accept=".pdf,.docx"
            icon="file"
            prompt="Drag a PDF or Word file here, or"
            hint="PDF or DOCX"
            fileName={docFileName}
            validate={(file) => /\.(pdf|docx)$/i.test(file.name)}
            onFile={(file) => { setDocFileName(file.name); onExtractDocument(file, meetingTitle); }}
          />
        </div>
      )}

      {activeTab === "paste" && (
        <div>
          <textarea
            id="transcript-box"
            className="input-dark min-h-[200px] resize-y leading-relaxed"
            placeholder="Paste the meeting transcript here..."
            value={pastedText}
            onChange={(e) => setPastedText(e.target.value)}
          />
          <button
            className="btn-primary mt-4 w-full"
            disabled={isBusy || !pastedText.trim()}
            onClick={() => onUseTranscript(pastedText, meetingTitle)}
          >
            <Icon name="sparkles" /> Generate minutes
          </button>
        </div>
      )}

      {statusMessage && (
        <div className="mt-5 flex items-center gap-2.5 rounded-xl border border-violet-400/20 bg-violet-500/10 px-4 py-3 text-sm text-violet-200">
          {isBusy && <span className="h-4 w-4 animate-spin rounded-full border-2 border-violet-300 border-t-transparent" />}
          {statusMessage}
        </div>
      )}
      {errorMessage && (
        <div className="mt-5 rounded-xl border border-rose-400/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-200">{errorMessage}</div>
      )}
    </div>
  );
}
