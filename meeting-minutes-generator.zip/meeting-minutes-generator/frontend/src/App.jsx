import { useEffect, useRef, useState } from "react";
import InputPanel from "./components/InputPanel.jsx";
import MinutesDocument from "./components/MinutesDocument.jsx";
import HistoryPanel from "./components/HistoryPanel.jsx";
import Navbar from "./components/Navbar.jsx";
import Hero from "./components/Hero.jsx";
import Features from "./components/Features.jsx";

const API_BASE = "/api";
const HISTORY_KEY = "minute.history.v1";

export default function App() {
  const [view, setView] = useState("generate"); // "generate" | "history"
  const [minutes, setMinutes] = useState(null);
  const [isBusy, setIsBusy] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [history, setHistory] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
    } catch {
      return [];
    }
  });

  const workspaceRef = useRef(null);

  useEffect(() => {
    if (minutes && view === "generate") {
      workspaceRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [minutes, view]);

  useEffect(() => {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  }, [history]);

  function saveToHistory(generatedMinutes) {
    const entry = {
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      minutes: generatedMinutes,
    };
    setHistory((prev) => [entry, ...prev].slice(0, 50));
  }

  async function generateMinutesFromTranscript(transcript, meetingTitle) {
    setStatusMessage("Analyzing transcript and drafting minutes...");
    const res = await fetch(`${API_BASE}/minutes`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ transcript, meeting_title: meetingTitle || undefined }),
    });
    if (!res.ok) {
      const detail = await safeErrorDetail(res);
      throw new Error(detail || "Could not generate minutes from this transcript.");
    }
    return res.json();
  }

  async function handleTranscribeFile(file, meetingTitle) {
    setErrorMessage("");
    setIsBusy(true);
    try {
      setStatusMessage("Transcribing audio...");
      const formData = new FormData();
      formData.append("file", file);

      const transcribeRes = await fetch(`${API_BASE}/transcribe`, {
        method: "POST",
        body: formData,
      });
      if (!transcribeRes.ok) {
        const detail = await safeErrorDetail(transcribeRes);
        throw new Error(detail || "Transcription failed.");
      }
      const { transcript } = await transcribeRes.json();

      const generated = await generateMinutesFromTranscript(transcript, meetingTitle);
      setMinutes(generated);
      saveToHistory(generated);
      setStatusMessage("Minutes ready.");
    } catch (err) {
      setErrorMessage(err.message);
      setStatusMessage("");
    } finally {
      setIsBusy(false);
    }
  }

  async function handleExtractDocument(file, meetingTitle) {
    setErrorMessage("");
    setIsBusy(true);
    try {
      setStatusMessage("Reading document...");
      const formData = new FormData();
      formData.append("file", file);

      const extractRes = await fetch(`${API_BASE}/extract-document`, {
        method: "POST",
        body: formData,
      });
      if (!extractRes.ok) {
        const detail = await safeErrorDetail(extractRes);
        throw new Error(detail || "Could not read this document.");
      }
      const { transcript } = await extractRes.json();

      const generated = await generateMinutesFromTranscript(transcript, meetingTitle);
      setMinutes(generated);
      saveToHistory(generated);
      setStatusMessage("Minutes ready.");
    } catch (err) {
      setErrorMessage(err.message);
      setStatusMessage("");
    } finally {
      setIsBusy(false);
    }
  }

  async function handleUseTranscript(transcript, meetingTitle) {
    setErrorMessage("");
    setIsBusy(true);
    try {
      const generated = await generateMinutesFromTranscript(transcript, meetingTitle);
      setMinutes(generated);
      saveToHistory(generated);
      setStatusMessage("Minutes ready.");
    } catch (err) {
      setErrorMessage(err.message);
      setStatusMessage("");
    } finally {
      setIsBusy(false);
    }
  }

  async function handleExport(format) {
    if (!minutes) return;
    setIsExporting(true);
    setErrorMessage("");
    try {
      const res = await fetch(`${API_BASE}/export/${format}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(minutes),
      });
      if (!res.ok) throw new Error(`Could not export as ${format.toUpperCase()}.`);

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${minutes.title.replace(/\s+/g, "_")}_minutes.${format}`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      setErrorMessage(err.message);
    } finally {
      setIsExporting(false);
    }
  }

  function handleNew() {
    setMinutes(null);
    setStatusMessage("");
    setErrorMessage("");
    setView("generate");
  }

  function handleOpenHistoryEntry(entry) {
    setMinutes(entry.minutes);
    setView("generate");
  }

  function handleDeleteHistoryEntry(id) {
    setHistory((prev) => prev.filter((e) => e.id !== id));
  }

  return (
    <div className="relative min-h-screen overflow-x-hidden">
      <Navbar
        view={view}
        setView={setView}
        historyCount={history.length}
        hasMinutes={!!minutes}
        onNew={handleNew}
      />

      {view === "generate" ? (
        <main>
          {!minutes && <Hero />}

          <section
            id="workspace"
            ref={workspaceRef}
            className={`relative mx-auto max-w-7xl scroll-mt-20 px-5 pb-24 ${minutes ? "pt-28" : "pt-4"}`}
          >
            {!minutes && (
              <div className="mx-auto mb-12 max-w-2xl text-center">
                <span className="text-sm font-semibold uppercase tracking-widest text-violet-400">Workspace</span>
                <h2 className="mt-3 text-3xl font-semibold tracking-tight text-white md:text-5xl">
                  Try it <span className="text-gradient">right now</span>
                </h2>
              </div>
            )}
            <div className="grid items-start gap-6 lg:grid-cols-[minmax(0,420px)_minmax(0,1fr)]">
              <div className="lg:sticky lg:top-24">
                <InputPanel
                  onTranscribeFile={handleTranscribeFile}
                  onExtractDocument={handleExtractDocument}
                  onUseTranscript={handleUseTranscript}
                  isBusy={isBusy}
                  statusMessage={statusMessage}
                  errorMessage={errorMessage}
                />
              </div>
              <MinutesDocument
                minutes={minutes}
                onExport={handleExport}
                isExporting={isExporting}
                isBusy={isBusy}
              />
            </div>
          </section>

          {!minutes && <Features />}
        </main>
      ) : (
        <HistoryPanel
          history={history}
          onOpen={handleOpenHistoryEntry}
          onDelete={handleDeleteHistoryEntry}
        />
      )}

      <footer className="border-t border-white/5 py-10 text-center text-sm text-zinc-600">
        <span className="font-semibold text-zinc-400">Minute<span className="text-violet-400">.</span></span>
        {" "}· AI-drafted meeting minutes from audio, documents, or transcript
      </footer>
    </div>
  );
}

async function safeErrorDetail(res) {
  try {
    const data = await res.json();
    return data.detail;
  } catch {
    return null;
  }
}
